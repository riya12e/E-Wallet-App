export interface WalletUserCredential{
    userName: string;
    password: string;
}
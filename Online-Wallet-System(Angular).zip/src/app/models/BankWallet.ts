export class BankWallet{
    walletAccountId: number;
    bankAccountId: number;
}
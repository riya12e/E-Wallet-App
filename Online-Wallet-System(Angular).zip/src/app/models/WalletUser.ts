export interface WalletUser{
    userId:number
    userName: string;
    password: string;
    phoneNumber: string;
    email:string;
}
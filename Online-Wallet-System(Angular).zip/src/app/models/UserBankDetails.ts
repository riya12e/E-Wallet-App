export interface UserBankDetails{
     accountNo:number;
     holderName:string;
     ifscCode:string;
     bankName:string;

}
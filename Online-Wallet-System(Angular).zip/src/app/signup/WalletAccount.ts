export class WalletAccount{
    accountId:number;
    accountBalance:number;
    status: string;
}